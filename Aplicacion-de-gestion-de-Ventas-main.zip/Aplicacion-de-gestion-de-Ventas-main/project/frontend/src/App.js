import './App.css';
import {FichaProducto} from './components/fichaProducto/fichaProducto';


function App() {
  return (
    <>
    <FichaProducto identificador="59">

      
    </FichaProducto>
    
    </>
    
  );
}

export default App;
